# Evidence

## Execution Evidence
----------------------

-> The application URL and API endpoints were not provided as part of the QA Assignment.

->Therefore, the Selenium automation scripts were created based on the given functional requirements 
but could not be executed.

->As a result, execution screenshots and runtime evidence are not available.

->The automation framework, manual test cases, boundary test cases, test data, and assumptions have been 
prepared according to the assignment requirements.

->Execution evidence can be generated once the application URL and valid test environment are provided.