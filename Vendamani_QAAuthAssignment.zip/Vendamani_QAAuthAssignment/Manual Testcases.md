#### &#x20;                                   Manual Testcases

&#x20;                                                              ----------------------------



Test case :

\-----------



&#x20;  Test case it is a detailed documentation which is help  to test the new software to the test engineers



&#x20;                 # In testcases we have 3 parts

&#x20;

&#x20;                          1.Header

&#x20;                          2.Body

&#x20;                          3.Footer





1.Header

\--------



&#x20;1. Testcase Name    : Future \_Registration

&#x20;2. Project Name     : Future work

&#x20;3. Release Name     : FT\_01

&#x20;4. Module  Name     : Registration

&#x20;5. Requirement No   :1.4.3

&#x20;6 .Severity        : critical

&#x20;7.Precondition     : 1. check the internet connection

&#x20;                     2. check the name and password

&#x20;                     3. check the roles and permission

8.Testcase type    : functional



9.Testcase execution hours : Time taken to write test case + execute the test case





2.Body :

\--------





|TC ID|Title|Test scenario|Precondition|Steps|Test Data|expected Result|priority|
|-|-|-|-|-|-|-|-|
|TC001|Verify successful registration|To check when user enter the<br />valid data into all fields and click on registration register successful message should be displayed|Registration page is open|1.Enter the all the valid data into all the fields<br />2.click on register|Name :Amun<br /><br />Email :amunit 28@gmail.com<br /><br />Password :Pass1234567<br /><br />conform Password :Pass1234567|User  successful registration<br />proper message should be displayed<br />(201 created)|High|
|TC002|Verify Name 'Text field'  is Mandatory|To check that Name 'Text field' is mandatory|Registration page is open|1.Leave the name is blank and click on Register|(Blank)don't enter anything|"Name is required "Validation" message should be displayed|High|
|TC003|Verify Name 'Text field' minimum length|To check that Name 'Text field 'should not accepted 4 characters|Registration page is open|1.Enter the 4 characters Name|John|It should not accepted proper validation error Message should be displayed<br />(400 Bad Request)|High|
|TC004|Verify Name 'Text field 'Maximum length|To check that Name 'Text field 'should not accepted 25 characters|Registration page is open|1.2.Enter the 25 characters Name|vendamani998765432qwertgf|It should not accepted proper validation error Message should be displayed<br />(400 Bad Request)|High|
|TC005|Verify Name 'Text field' Range|To check that Name 'Text field' should accept between 5 and 25 characters|Registration page is open|1.Enter the between 2 t0 25 characters|Reena|It should be accepted<br />(201 created)|High|
|TC006|Verify Name 'Text field' is editable|To check that Name 'Text field' is editable before execution|Registration page is open|1.First enter invalid data<br />2.after edit the correct data|Rena<br />Reena|It should be accepted<br />(201 created)|Medium|
|TC007|Verify Name 'Text field' accept alphabet characters only|To check that Name 'Text field' should accept alphabet characters only|Registration page is open|1.Enter alphabet only|Maheshwari|It should be accepted <br />(201 created)|High|
|TC008|Verify Name 'Text field' should accepted exact 5 characters|To check that Name 'Text field' should accept 5  characters|Registration page is open|1.Enter the exact 5 characters|sadhu|It should be accepted<br />(201 created)|High|
|TC009|Verify Name 'Text field' should accepted exact 24 characters|To check that Name 'Text field' should accept 25 characters|Registration page is open|1.Enter the exact 25 characters|vendamani987654321gfdtjhr|It should be accepted<br />(201 created)|High|
|TC010|Verify Name 'Text field' Place holder|To check that Name 'Text field should display place holder stating Name|Registration page is open|Not Applicable|Not Applicable|Place holder stating Name should be displayed|Low|
|TC011|Verify Name 'Text field' should not accept emoji|To check that Name 'Text field'<br />should accept emoji|Registration page is open|1.Enter emojis|😇🥰🥰|It should not be accepted<br />(400 Bad request)|High|
|TC012|Verify valid Email format|To check that Email 'Text field' should accept only valid email|Registration page is open|1.Enter valid email id|venda@gmail.com|It should be accepted<br />(201 created)|High|
|TC013|Verify invalid Email format|To check that Email 'Text field' should not accept invalid email|Registration page is open|1.Enter invalid email id|vendagmail.com|It should not be accepted<br />(400 Bad request)|High|
|TC014|Verify duplicate email registration|To check that Email 'Text field 'should not accept duplicate email|Registration page is open|1.Enter duplicate email|venda@gmail.com|Duplicate email id should not accepted <br />(409 conflict)|High|
|TC015|Verify @@ symbol|To check that Email 'Text field' should not accept @@ symbol|Registration page is open|1.Enter the email with two @@|venda@@gmail.com|It should not be accepted<br />(400 Bad request)|High|
|TC016|verify Email 'Text field' with different domain|To check that Email 'Text field should accepted different domains|Registration page is open|1.Enter the valid Email id with different domain|venda@yahoo.com<br />vend@outlook.com|It should be accepted<br />(201 created)|High|
|TC017|Verify Password 'Text field' minimum length|To check that Password 'Text field' should not accepted 11 characters|Registration page is open|1.Enter the 11 characters|Vendaram@8765|It should not be accepted validation error displayed<br />(400 Bad request)|High|
|TC018|Verify Password 'Text field 'maximum length|To check that Password 'Text field' should not accepted 13 characters|Registration page is open|1.Enter the 13 characters|Vendaram@876556|It should not be accepted validation error displayed<br />(400 Bad request)|High|
|TC019|Verify Password 'Text field' exact 12 length|To check that Password 'Text field' should  accepted 12 characters|Registration page is open|1.Enter the 12 characters|Vendaram@87657|It should be accepted<br />(201 created)|High|
|<br /><br />TC020|Verify Password 'Text field' without number|To check that Password 'Text field' should not accepted without numbers|Registration page is open|1.Enter the 12 characters without numbers|Vendaram@venda|It should not be accepted validation error displayed<br />(400 Bad request)|High|
|<br /><br />TC021|Verify Password 'Text field' without letters|To check that Password 'Text field' should not accepted without letters|Registration page is open|1.Enter the 12 characters without letters|43567245@##6|It should not be accepted validation error displayed<br />(400 Bad request)|High|
|<br />TC022|Verify Password 'Text field'  is Mandatory|To check that Password 'Text field' is mandatory|Registration page is open|1.Leave the name is blank and click on Register|(Blank)don't enter anything|"Name is required "Validation" message should be displayed|High|
|<br />TC023|Verify Password 'Text field'  place holder|To check that Password 'Text field' place holder stating is Password|Registration page is open|Not Applicable|Not Applicable|Password 'Text field'  should be displayed place  holder stating is Password|Low|
|<br />TC024|Verify Password 'Text field'  not accept emoji|To check Password 'Text field' should not accept emoji|Registration page is open|1.Enter the emoji|😇🥰🥰|It should not be accepted<br />(400 Bad request)|High|
|<br />TC025|Verify Conform Password Mismatch|To check that Conform password 'Text field' should not accept different password|Registration page is open|1.Enter different Password|Vendaram@#23<br />|It should not be accepted<br />(400 Bad request)|High|
|TC026|Verify conform Password 'Text field'  place holder|To check that Password 'Text field' place holder stating is conform Password|Registration page is open|Not Applicable|Not Applicable|conform Password 'Text field'  should be displayed place  holder stating is conform Password|Low|
|TC027|Verify all the fields are Mandatory|To check that all the fields are Mandatory|Registration page is open|1.Leave the name is blank and click on Register|Not Applicable|Required field validation message should displayed|High|
|TC028|Verify successful login|To check that when user enter valid email and password click on login successful login|user is already registered|1.Enter the valid email id <br />2.Enter the valid password|venda2@gmail.com<br />Vendaram@28|Login successful message should be displayed and dashboard should be displayed<br />(201 created)|High|
|TC029|Verify login with invalid password|To check that when user enter valid email and invalid password click on login error message should be displayed|user is already registered|1.Enter the valid email id<br />2.Enter the invalid password|venda2@gmail.com<br />111111ndaram@28|Invalid Password proper error message should displayed<br />(401 unauthorized)|High|
|TC030|Verify login with unregistered email|To check that when user enter unregistered email id proper error message displayed|Login Page is open|1.Enter the unregister mail id|rishi@gmail.com| Proper error message displayed<br />(401 unauthorized)|High|
|TC031|Verify dashboard access after login|To check when user access the dashboard after login|User is loggined in|1.user is navigate to the dashboard|Valid JWT token|Dashboard should displayed successfully<br />(200 -ok)|High|
|TC032|Verify dashboard access without login|To check when user access the dashboard before login|user is not login|1.open enter dashboard Url|No JWT Token|Redirected to login page <br />(401-unauthorized)|High|
|TC033|Verify expired JWT token|To check when user can login the dashboard expired JWT token|user login for expired data|1.Enter the expired JWT token|ghdfsfyuerhfjkjghsjdfyrfghg|session expired Redirected to login page<br />(401 unauthorized)<br />|Medium|
|TC034|Verify rate limit|To check that rate limit user send 10 attempts|Registration page is open|1.Register 10 times|10 email id and password|All the request are allowed|Medium|
|TC035|Verify rate limit|To check that rate limit user send 11 attempts|Registration page is open|1.Register 11 times|11 email id and password|429-Too many request should be displayed|High|
|TC036|Verify SQl injection|To check that SQL injection|Registration page is open|1.Enter SQL injection|"OR'1'='1'|input is rejected should be displayed<br />(Bad request)|High|
|TC037|Verify concurrent registration|To check that concurrent registration||||First request :201 created<br />------------<br />second request:409 conflict(because of email is already registered)|High|





3\. Footer :

\-----------

&#x20;

&#x20;    Author      : ram

&#x20;    Reviewed by : Swetha

&#x20;    Approved by : pooja

&#x20;    Approval date : 17/07/2026









&#x20;

