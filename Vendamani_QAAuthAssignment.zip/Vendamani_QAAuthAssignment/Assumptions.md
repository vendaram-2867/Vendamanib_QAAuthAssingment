#### **Assumptions :**

**----------------------**







**Environment Setup**

**-----------------**



**- Application is deployed and accessible through a valid URL.**

**- Backend APIs are running successfully.**

**- Database is available and stores registered users.**



&#x20;**JWT Behaviour**

**---------------**



**- JWT token is generated after successful login.**

**- Token is stored securely (Local Storage/Session Storage).**

**- Every protected API request requires a valid JWT token.**



**Token Expiration**

**----------------**

**- Expired JWT tokens should return HTTP 401 Unauthorized.**

**- User should be redirected to the Login page after token expiry.**



&#x20;**Validation Rules**

**------------------**

**- Email is converted to lowercase before saving.**

**- Duplicate emails are not allowed.**

**- Name must contain 5–24 characters.**

**- Password must be at least 12 characters and contain both letters and numbers.**

**- Confirm Password must exactly match Password.**

