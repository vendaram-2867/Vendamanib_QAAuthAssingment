### **Boundary Test Cases**

**--------------------------------------**



**Definition : If the input is range of the values between A and B design the testcase for A , A-1 ,A+1 , B , B+1 ,B-1**



**Name Text field** 

**---------------**

|     BC ID|    Field| Test scenario|Boundary Value|Test Data|Expected Result|
|-|-|-|-|-|-|
|     BC001| Name 'Text field'|To check that Name<br />'Text field' should accept 5 characters|5 characters|shiva|It should be accepted|
|     BC002| Name 'Text field'|To check that Name 'Text field should accept 6 characters|6 characters|ram@12|It should be accepted|
|     BC003| Name 'Text field'|To check that Name 'Text field should accept 24 characters|24 characters|vendamani987654321gdhye@r|It should be accepted|
|     BC004| Name 'Text field'|To check that Name 'Text field should accept 23 characters|23 characters|sadhuyuvarishivendha76@r|It should be accepted|
|     BC005| Name 'Text field'|To check that Name 'Text field should not accept 4 characters|4 characters|6tf3|It should  not be accepted|
|     BC006| Name 'Text field'|To check that Name 'Text field should not accept 26 characters|26 characters|tvendamani987654321gdhye@r|It should not be accepted|





**Email Text field** 

**----------------**

|      BC ID|      Field|  Test scenario| Boundary Value|  Test Data|Expected Result|
|-|-|-|-|-|-|
|      BC007|Email 'Text field'|To check that uppercase email id should accept|uppercase email|JOHN@GMAIL.COM|uppercase should converted to lowercase and it should be accepted|
|      BC008|Email 'Text field'|To check that Email 'Text field leading space it should not be accepted|Leading space|" amul@gmail.com"|space trimmed or validation message should be displayed|
|      BC009|Email 'Text field'|To check that Email 'Text field Trailing space it should not be accepted|Trailing space|"amul@gmail.com "|space trimmed or validation message should be displayed|
|      BC010|Email 'Text field'|To check that Email 'Text field should accept very long email|Very long valid email|verylongemail123456@gmail.com|It should be accepted|



**Password Text field**

**-------------------**

|     BC ID|    Field|Test scenario| Boundary value|  Test Data|Expected Result|
|-|-|-|-|-|-|
|     BC011|Password 'Text field'|To check that password 'Text field should accept 12 characters|12 characters|Spass1234567|It should be accepted|
|     BC012|Password 'Text field'|To check that Password 'Text field should not accept 11 characters |11 characters|Sass1234567|It should not be accepted proper error message should be displayed|
|     BC013|Password 'Text field'|To check that Password 'Text field should not accept 13 characters|13 characters|Saas12345678|It should not be accepted proper error message should displayed|



**Conform Password Text field**

**---------------------------**

|    BC ID|   Field|Test scenario|Boundary value| Test Data| Expected Result|
|-|-|-|-|-|-|
|    BC015|Conform Password 'Text Field'|To check that Conform Password 'Text Field 'should accept  only exact matching password|Exact Match|Pass12345678|It should be accepted|
|    BC016|Conform Password 'Text Field'|To check that Conform Password 'Text Field 'should not accept one characters less also|One character less|Pass1234567|It should not be accepted Password does not match proper error message should be displayed|
|    BC017|Conform Password 'Text Field'|To check that Conform Password 'Text Field 'should not accept one characters extra also|One character extra|Pass12345678|It should not be accepted Password does not match proper error message should be displayed|



Rate Limiting

\--------------

|     BC ID|      Field| Test scenario|Boundary value| Test Data| Expected Result|
|-|-|-|-|-|-|
|     BC016|Registration Attempts|To check when user 10 times Registration still its allow to request|10 attempts|Same IP|Requested allowed status code should be displayed|
|     BC017|Registration Attempts|To check when user 11 times Registration too many request message should be displayed|11 attempts|Same IP|429 Too Many Requests<br />status code should be displayed|





