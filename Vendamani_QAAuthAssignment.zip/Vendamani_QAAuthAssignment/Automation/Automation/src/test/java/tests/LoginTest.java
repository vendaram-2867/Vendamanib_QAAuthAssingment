package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {



	   @Test

	   public void successfulLogin() {



	      driver.findElement(By.id("email"))

	            .sendKeys("john123@gmail.com");



	     driver.findElement(By.id("password"))

	            .sendKeys("Password1234");



	      driver.findElement(By.id("loginBtn")).click();



	      String actualTitle = driver.getTitle();



	      Assert.assertEquals(actualTitle, "Dashboard");



	  }



	  @Test

	   public void invalidPasswordLogin() {



	       driver.findElement(By.id("email"))

	            .sendKeys("john123@gmail.com");



	     driver.findElement(By.id("password")).sendKeys("WrongPassword123");



	       driver.findElement(By.id("loginBtn")).click();



	       String errorMessage = driver.findElement(By.id("errorMessage")).getText();



	       Assert.assertEquals(errorMessage, "Invalid Credentials");



	   }



	}


