package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegistrationTest extends BaseTest {

	@Test

	public void successfulRegistration() {

		driver.findElement(By.id("name")).sendKeys("John Smith");

		driver.findElement(By.id("email")).sendKeys("john123@gmail.com");

		driver.findElement(By.id("password")).sendKeys("Password1234");

		driver.findElement(By.id("confirmPassword")).sendKeys("Password1234");

		driver.findElement(By.id("registerBtn")).click();

		String message = driver.findElement(By.id("successMessage")).getText();

		Assert.assertEquals(message, "Registration Successful");

	}

	@Test

	public void duplicateEmailRegistration() {

		driver.findElement(By.id("name")).sendKeys("John Smith");

		driver.findElement(By.id("email")).sendKeys("john@gmail.com");

		driver.findElement(By.id("password")).sendKeys("Password1234");

		driver.findElement(By.id("confirmPassword")).sendKeys("Password1234");

		driver.findElement(By.id("registerBtn")).click();

		String error = driver.findElement(By.id("errorMessage")).getText();

		Assert.assertEquals(error, "Email already exists");

	}

}
