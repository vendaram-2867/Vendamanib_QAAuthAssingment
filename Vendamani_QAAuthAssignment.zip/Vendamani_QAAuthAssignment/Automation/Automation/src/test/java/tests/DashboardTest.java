package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DashboardTest extends BaseTest {



	  @Test

	  public void accessDashboardWithoutLogin() {



	       // Open dashboard directly without login

	      driver.get("http://localhost:3000/dashboard");



	       // Verify user is redirected to Login page

	       String currentUrl = driver.getCurrentUrl();



	      Assert.assertTrue(currentUrl.contains("login"));



	   }



	  @Test

	   public void verifyDashboardAfterLogin() {



	       driver.findElement(By.id("email"))

	             .sendKeys("john123@gmail.com");



	     driver.findElement(By.id("password"))

	               .sendKeys("Password1234");



	      driver.findElement(By.id("loginBtn")).click();



	     String currentUrl = driver.getCurrentUrl();



	       Assert.assertTrue(currentUrl.contains("dashboard"));



	  }



	}

